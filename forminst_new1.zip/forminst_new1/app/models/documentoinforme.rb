class Documentoinforme < ActiveRecord::Base
	belongs_to :informe
end