class Tutor < ActiveRecord::Base
	belongs_to :usuario
end
