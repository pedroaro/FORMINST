class Area < ActiveRecord::Base
	has_many :usuario
end
