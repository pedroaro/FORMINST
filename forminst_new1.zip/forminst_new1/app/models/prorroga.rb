class Prorroga < ActiveRecord::Base
	belongs_to :planformacion
end