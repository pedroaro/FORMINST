class DocumentoInforme < ActiveRecord::Base
	belongs_to :informe
end
