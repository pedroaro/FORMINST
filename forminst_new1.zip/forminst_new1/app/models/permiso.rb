class Permiso < ActiveRecord::Base
	has_many :permisologium
end