class Documento < ActiveRecord::Base
	belongs_to :informe_actividad
end