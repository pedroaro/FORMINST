class Observaciontutor < ActiveRecord::Base
	belongs_to :informeactividad
end