class Actividadejecutada < ActiveRecord::Base
	belongs_to :informeactividad
end