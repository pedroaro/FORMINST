class Documentoplan < ActiveRecord::Base
	belongs_to :planformacion
end