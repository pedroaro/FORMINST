class TipoInforme < ActiveRecord::Base
	has_one :informe
end
