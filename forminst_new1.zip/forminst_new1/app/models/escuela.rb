class Escuela < ActiveRecord::Base
	has_many :entidad
end