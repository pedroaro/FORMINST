class ObservacionTutor < ActiveRecord::Base
	belongs_to :informe_actividad
end
