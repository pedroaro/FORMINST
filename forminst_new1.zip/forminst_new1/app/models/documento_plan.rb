class DocumentoPlan < ActiveRecord::Base
	belongs_to :planformacion
end
