class Persona < ActiveRecord::Base
	belongs_to :usuario
end