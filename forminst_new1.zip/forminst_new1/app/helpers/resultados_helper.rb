module ResultadosHelper
end
