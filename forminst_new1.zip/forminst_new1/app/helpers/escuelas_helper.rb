module EscuelasHelper
end
