require 'test_helper'

class ObservaciontutorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
