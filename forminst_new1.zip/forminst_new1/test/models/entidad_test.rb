require 'test_helper'

class EntidadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
