require 'test_helper'

class ActividadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
