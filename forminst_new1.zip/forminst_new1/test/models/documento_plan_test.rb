require 'test_helper'

class DocumentoPlanTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
