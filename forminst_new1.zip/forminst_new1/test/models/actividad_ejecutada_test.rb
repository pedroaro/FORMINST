require 'test_helper'

class ActividadEjecutadaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
