require 'test_helper'

class DocumentoinformeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
