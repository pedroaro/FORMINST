require 'test_helper'

class ResultadoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
