require 'test_helper'

class AdecuacionactividadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
