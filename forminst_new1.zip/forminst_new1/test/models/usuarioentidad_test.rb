require 'test_helper'

class UsuarioentidadTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
