require 'test_helper'

class EstatusadecuacionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
