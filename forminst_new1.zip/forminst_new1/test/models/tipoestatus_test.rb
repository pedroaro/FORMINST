require 'test_helper'

class TipoestatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
