require 'test_helper'

class InformeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
