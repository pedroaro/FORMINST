require 'test_helper'

class EstatusInformeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
