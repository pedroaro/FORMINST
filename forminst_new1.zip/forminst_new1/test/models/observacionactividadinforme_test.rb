require 'test_helper'

class ObservacionactividadinformeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
