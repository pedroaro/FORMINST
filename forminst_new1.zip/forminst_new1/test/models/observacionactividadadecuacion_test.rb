require 'test_helper'

class ObservacionactividadadecuacionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
