require 'test_helper'

class ProrrogaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
