require 'test_helper'

class PermisoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
