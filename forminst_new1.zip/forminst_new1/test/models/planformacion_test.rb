require 'test_helper'

class PlanformacionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
