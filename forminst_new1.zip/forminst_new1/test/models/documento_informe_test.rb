require 'test_helper'

class DocumentoInformeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
