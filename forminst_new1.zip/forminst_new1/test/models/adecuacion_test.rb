require 'test_helper'

class AdecuacionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
