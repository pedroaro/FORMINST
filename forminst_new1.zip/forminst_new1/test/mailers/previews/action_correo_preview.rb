# Preview all emails at http://localhost:3000/rails/mailers/action_correo
class ActionCorreoPreview < ActionMailer::Preview

end
