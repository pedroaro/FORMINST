require 'test_helper'

class ForminstHelperTest < ActionView::TestCase
end
