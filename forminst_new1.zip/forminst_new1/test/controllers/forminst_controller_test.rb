require 'test_helper'

class ForminstControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
