class CreateUsuarios < ActiveRecord::Migration
  def change
    create_table :usuarios do |t|

      t.timestamps
    end
  end
end
