class CreateEntidads < ActiveRecord::Migration
  def change
    create_table :entidads do |t|

      t.timestamps
    end
  end
end
